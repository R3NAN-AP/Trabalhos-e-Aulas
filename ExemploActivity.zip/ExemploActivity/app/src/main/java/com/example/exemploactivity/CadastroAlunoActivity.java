package com.example.exemploactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CadastroAlunoActivity extends AppCompatActivity {
    private TextView tvListaAlunos;
    private Button btSalvar;
    private EditText edNomeAluno;
    private EditText edRaAluno;
    private EditText edDataNascimento;

    private EditText edCpfAluno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_aluno);

        tvListaAlunos = findViewById(R.id.tvListaAlunos);
        edRaAluno = findViewById(R.id.edRaAluno);
        edNomeAluno = findViewById(R.id.edNomeAluno);
        edCpfAluno = findViewById(R.id.edCpfAluno);
        edDataNascimento = findViewById(R.id.edDataNascimento);
        btSalvar = findViewById(R.id.btSalvar);
        btSalvar.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                salvarAluno();
            }
        });


        btSalvar = findViewById(R.id.btSalvar);
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarAluno();
            }
        });
        atualizarLista();
    }

    private void salvarAluno() {
        int ra;



        if (edRaAluno.getText().toString().isEmpty()) {
            edRaAluno.setError("O RA do Aluno deve ser informado!!");
            return;

        } else {
            try {
                ra = Integer.parseInt(edRaAluno.getText().toString());

            } catch (Exception ex) {
                edRaAluno.setError("Informe um RA valido( somente números)!");
                return;
            }
        }
        if (edNomeAluno.getText().toString().isEmpty()) {
            edNomeAluno.setError("O Nome do Aluno deve ser informado!");
            return;
        }
        if (edDataNascimento.getText().toString().isEmpty()) {
            edDataNascimento.setError("A data de nascimento deve ser informada!");
            return;
        }
        if (edCpfAluno.getText().toString().isEmpty()) {
            edCpfAluno.setError("O CPF do Aluno deve ser informado!!");
            return;

        }

            Aluno aluno = new Aluno();
            aluno.setRa(ra);
            aluno.setNome(edNomeAluno.getText().toString());
            aluno.setCpf(edCpfAluno.getText().toString());
            aluno.setData(edDataNascimento.getText().toString());

            Controller.getInstancia().salvarAluno(aluno);

            Toast.makeText(CadastroAlunoActivity.this,

                    "Aluno Cadastrado com Sucesso!!", Toast.LENGTH_LONG).show();
            finish();
        }


    private void atualizarLista() {
        String texto = "";

        ArrayList<Aluno> lista = Controller.getInstancia().retornarAluno();
        for (Aluno aluno : lista) {

            texto += aluno.getRa() + " - " + aluno.getNome() + " - "+ aluno.getCpf() + " - "+ aluno.getData() + "\n";
        }
          tvListaAlunos.setText(texto);
    }
}