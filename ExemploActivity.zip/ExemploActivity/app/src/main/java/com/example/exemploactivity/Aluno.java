package com.example.exemploactivity;

import android.widget.TextView;

public class Aluno {
    private TextView tvListaAlunos;

    private int ra;
    private String nome;

    private String cpf;

    private String data;

    public Aluno() {

    }

    public int getRa() {
        return ra;
    }

    public void setRa(int ra) {
        this.ra = ra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public TextView getTvListaAlunos() {
        return tvListaAlunos;
    }

    public void setTvListaAlunos(TextView tvListaAlunos) {
        this.tvListaAlunos = tvListaAlunos;
    }
}

